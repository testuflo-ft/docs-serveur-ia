const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const vm = require("node:vm");

const safeMove = require("../server/utils/files/safeMove");

function tempRoot(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "allm-safe-move-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  return root;
}
function put(file, content = "content") {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content);
}
function loadMoveProcessedDocsFunction() {
  const source = fs.readFileSync(
    path.join(__dirname, "../server/utils/files/index.js"), "utf8"
  );
  const start = source.indexOf("function moveProcessedDocsToFolder(");
  const end = source.indexOf("\n/**", start);
  assert.ok(start >= 0 && end > start, "function source found");
  const code = source.slice(start, end);
  const sandbox = {
    fs, path,
    normalizePath(filepath = "") {
      const result = path.normalize(filepath.trim())
        .replace(/^(\.\.(\/|\\|$))+/, "").trim();
      if (["..", ".", "/"].includes(result)) throw new Error("Invalid path.");
      return result;
    },
    isWithinRoot: safeMove.isWithinRoot,
    moveFileNoReplace: safeMove.moveFileNoReplace,
    assertSafeDirectory: safeMove.assertSafeDirectory,
    assertSafeRegularFile: safeMove.assertSafeRegularFile,
    assertSafeDestination: safeMove.assertSafeDestination,
  };
  vm.runInNewContext(`${code}; globalThis.fn = moveProcessedDocsToFolder;`, sandbox);
  return sandbox.fn;
}

test("moveFileNoReplace moves a regular file", (t) => {
  const root = tempRoot(t);
  const from = path.join(root, "source", "a.txt");
  const to = path.join(root, "target", "a.txt");
  put(from, "hello");
  fs.mkdirSync(path.dirname(to));
  safeMove.moveFileNoReplace(root, from, to);
  assert.equal(fs.existsSync(from), false);
  assert.equal(fs.readFileSync(to, "utf8"), "hello");
});

test("moveFileNoReplace refuses to overwrite an existing destination", (t) => {
  const root = tempRoot(t);
  const from = path.join(root, "a.txt");
  const to = path.join(root, "b.txt");
  put(from, "source");
  put(to, "destination");
  assert.throws(() => safeMove.moveFileNoReplace(root, from, to), { code: "EEXIST" });
  assert.equal(fs.readFileSync(from, "utf8"), "source");
  assert.equal(fs.readFileSync(to, "utf8"), "destination");
});

test("moveFileNoReplace removes destination if unlinking source fails", (t) => {
  const root = tempRoot(t);
  const from = path.join(root, "source.txt");
  const to = path.join(root, "destination.txt");
  put(from, "preserve-me");
  const originalUnlink = fs.unlinkSync;
  fs.unlinkSync = function (target, ...args) {
    if (path.resolve(target) === path.resolve(from)) {
      const error = new Error("simulated source unlink failure");
      error.code = "EACCES";
      throw error;
    }
    return originalUnlink.call(fs, target, ...args);
  };
  try {
    assert.throws(
      () => safeMove.moveFileNoReplace(root, from, to),
      { code: "EACCES" }
    );
  } finally {
    fs.unlinkSync = originalUnlink;
  }
  assert.equal(fs.readFileSync(from, "utf8"), "preserve-me");
  assert.equal(fs.existsSync(to), false);
});

test("moveFileNoReplace rejects a symlink source", (t) => {
  const root = tempRoot(t);
  const outside = path.join(os.tmpdir(), `allm-outside-${process.pid}`);
  put(outside, "outside");
  t.after(() => fs.rmSync(outside, { force: true }));
  const link = path.join(root, "link");
  fs.symlinkSync(outside, link);
  assert.throws(() => safeMove.moveFileNoReplace(root, link, path.join(root, "dest")), {
    code: "UNSAFE_SOURCE",
  });
  assert.equal(fs.readFileSync(outside, "utf8"), "outside");
});

test("moveFileNoReplace rejects symlink parent directories", (t) => {
  const root = tempRoot(t);
  const outside = path.join(os.tmpdir(), `allm-outside-dir-${process.pid}`);
  fs.mkdirSync(outside, { recursive: true });
  t.after(() => fs.rmSync(outside, { recursive: true, force: true }));
  fs.symlinkSync(outside, path.join(root, "linked-dir"));
  assert.throws(() => safeMove.moveFileNoReplace(
    root, path.join(root, "linked-dir", "source"), path.join(root, "dest")
  ));
});

test("resolveSafeRelative rejects traversal, absolute and backslash paths", (t) => {
  const root = tempRoot(t);
  for (const candidate of ["../outside", "/tmp/outside", "a/../b", "a\\b", "a//b"]) {
    assert.throws(() => safeMove.resolveSafeRelative(root, candidate), candidate);
  }
});

test("INT-18 prevalidates duplicate destination names before moving", (t) => {
  const root = tempRoot(t);
  const a = path.join(root, "one", "same.json");
  const b = path.join(root, "two", "same.json");
  put(a, "one"); put(b, "two");
  const fn = loadMoveProcessedDocsFunction();
  const docs = [
    { location: "one/same.json", name: "same.json" },
    { location: "two/same.json", name: "same.json" },
  ];
  assert.throws(() => fn(docs, "target", root), /Duplicate destination/);
  assert.equal(fs.readFileSync(a, "utf8"), "one");
  assert.equal(fs.readFileSync(b, "utf8"), "two");
});

test("INT-18 moves multiple files and updates metadata only on success", (t) => {
  const root = tempRoot(t);
  put(path.join(root, "one", "a.json"), "A");
  put(path.join(root, "two", "b.json"), "B");
  const fn = loadMoveProcessedDocsFunction();
  const docs = [
    { location: "one/a.json", name: "a.json" },
    { location: "two/b.json", name: "b.json" },
  ];
  assert.equal(fn(docs, "target", root), "target");
  assert.equal(fs.readFileSync(path.join(root, "target", "a.json"), "utf8"), "A");
  assert.equal(fs.readFileSync(path.join(root, "target", "b.json"), "utf8"), "B");
  assert.deepEqual(docs.map((d) => d.location), ["target/a.json", "target/b.json"]);
});

test("INT-18 refuses symlink source and leaves target content untouched", (t) => {
  const root = tempRoot(t);
  const outside = path.join(os.tmpdir(), `allm-int18-outside-${process.pid}`);
  put(outside, "outside");
  t.after(() => fs.rmSync(outside, { force: true }));
  fs.mkdirSync(path.join(root, "source"));
  fs.symlinkSync(outside, path.join(root, "source", "a.json"));
  const fn = loadMoveProcessedDocsFunction();
  assert.throws(() => fn([{ location: "source/a.json", name: "a.json" }], "target", root));
  assert.equal(fs.readFileSync(outside, "utf8"), "outside");
});

function loadPurgeFolderFunction(root, calls, behavior = {}) {
  const source = fs.readFileSync(
    path.join(__dirname, "../server/utils/files/purgeDocument.js"), "utf8"
  );
  const start = source.indexOf("async function purgeFolder(");
  const end = source.indexOf("\nmodule.exports", start);
  assert.ok(start >= 0 && end > start, "purgeFolder source found");
  const code = source.slice(start, end);
  const sandbox = {
    fs, path, documentsPath: root,
    normalizePath(filepath = "") {
      const result = path.normalize(filepath.trim())
        .replace(/^(\.\.(\/|\\|$))+/, "").trim();
      if (["..", ".", "/"].includes(result)) throw new Error("Invalid path.");
      return result;
    },
    isWithin(outer, inner) {
      const resolvedOuter = path.resolve(outer);
      const resolvedInner = path.resolve(inner);
      const rel = path.relative(resolvedOuter, resolvedInner);
      if (rel === "") return false;
      return !rel.startsWith(`..${path.sep}`) && rel !== ".." && !path.isAbsolute(rel);
    },
    purgeVectorCache: async (filename) => {
      calls.cache.push(filename);
      if (behavior.failCache === filename) throw new Error("cache failure");
    },
    Workspace: { where: async () => [{ slug: "ws1" }, { slug: "ws2" }] },
    Document: { removeDocuments: async (workspace, filenames) => {
      calls.documents.push({ workspace: workspace.slug, filenames: [...filenames] });
      if (behavior.failWorkspace === workspace.slug) throw new Error("database failure");
    } },
  };
  vm.runInNewContext(`${code}; globalThis.fn = purgeFolder;`, sandbox);
  return sandbox.fn;
}

test("PUR-02 recursively purges nested and hidden files and reports each cleanup", async (t) => {
  const root = tempRoot(t);
  const folder = path.join(root, "reports");
  put(path.join(folder, "nested", ".hidden"), "secret");
  put(path.join(folder, "top.txt"), "top");
  const calls = { cache: [], documents: [] };
  const purge = loadPurgeFolderFunction(root, calls);
  const result = await purge("reports");
  assert.equal(result.success, true);
  assert.equal(fs.existsSync(folder), false);
  assert.deepEqual([...calls.cache].sort(), ["reports/nested/.hidden", "reports/top.txt"]);
  assert.equal(calls.documents.length, 2);
});

test("PUR-02 refuses protected custom-documents with 403", async (t) => {
  const root = tempRoot(t);
  fs.mkdirSync(path.join(root, "custom-documents"));
  const purge = loadPurgeFolderFunction(root, { cache: [], documents: [] });
  await assert.rejects(() => purge("custom-documents"), { statusCode: 403, code: "FOLDER_PROTECTED" });
});

test("PUR-02 refuses symbolic links without deleting their targets", async (t) => {
  const root = tempRoot(t);
  const outside = path.join(os.tmpdir(), `allm-purge-outside-${process.pid}`);
  put(outside, "keep");
  t.after(() => fs.rmSync(outside, { force: true }));
  const folder = path.join(root, "reports");
  fs.mkdirSync(folder);
  fs.symlinkSync(outside, path.join(folder, "link"));
  const calls = { cache: [], documents: [] };
  const purge = loadPurgeFolderFunction(root, calls);
  await assert.rejects(() => purge("reports"), { statusCode: 400, code: "UNSUPPORTED_FOLDER_ENTRY" });
  assert.equal(fs.readFileSync(outside, "utf8"), "keep");
  assert.equal(fs.existsSync(folder), true);
  assert.equal(calls.cache.length, 0);
});

test("PUR-02 retains folder when a cache cleanup fails", async (t) => {
  const root = tempRoot(t);
  const folder = path.join(root, "reports");
  put(path.join(folder, "a.txt"), "A");
  put(path.join(folder, "b.txt"), "B");
  const calls = { cache: [], documents: [] };
  const purge = loadPurgeFolderFunction(root, calls, { failCache: "reports/a.txt" });
  await assert.rejects(() => purge("reports"), /cache failure/);
  assert.equal(fs.existsSync(folder), true);
  assert.equal(calls.documents.length, 0);
});

test("INT-18 rejects a traversal folder name before normalization", (t) => {
  const root = tempRoot(t);
  put(path.join(root, "source", "a.json"), "A");
  const fn = loadMoveProcessedDocsFunction();
  assert.throws(() => fn([{ location: "source/a.json", name: "a.json" }], "../target", root));
  assert.equal(fs.existsSync(path.join(root, "source", "a.json")), true);
});

test("INT-18 rolls back earlier moves when a later move fails", (t) => {
  const root = tempRoot(t);
  put(path.join(root, "one", "a.json"), "A");
  put(path.join(root, "two", "b.json"), "B");
  const fn = loadMoveProcessedDocsFunction();
  const docs = [
    { location: "one/a.json", name: "a.json" },
    { location: "two/b.json", name: "b.json" },
  ];
  const originalLink = fs.linkSync;
  let failed = false;
  fs.linkSync = function(source, destination) {
    if (!failed && destination === path.join(root, "target", "b.json")) {
      failed = true;
      const error = new Error("simulated link failure");
      error.code = "EIO";
      throw error;
    }
    return originalLink.call(fs, source, destination);
  };
  try {
    assert.throws(() => fn(docs, "target", root), /prior moves rolled back/);
  } finally {
    fs.linkSync = originalLink;
  }
  assert.equal(fs.readFileSync(path.join(root, "one", "a.json"), "utf8"), "A");
  assert.equal(fs.readFileSync(path.join(root, "two", "b.json"), "utf8"), "B");
  assert.equal(fs.existsSync(path.join(root, "target")), false);
  assert.deepEqual(docs.map((d) => d.location), ["one/a.json", "two/b.json"]);
});

test("INT-19 Swagger response examples are attached to move-files, not create-folder", () => {
  const source = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/api/document/index.js"), "utf8"
  );
  const createStart = source.indexOf('"/v1/document/create-folder"');
  const moveStart = source.indexOf('"/v1/document/move-files"');
  assert.ok(createStart >= 0 && moveStart > createStart);
  const createRoute = source.slice(createStart, moveStart);
  const moveRoute = source.slice(moveStart, source.indexOf('"/v1/document/generated-files/', moveStart));
  assert.doesNotMatch(createRoute, /Some files were not moved; inspect results/);
  assert.match(moveRoute, /Some files were not moved; inspect results/);
  assert.match(moveRoute, /summary: \{ requested: 3, moved: 1, failed: 1, embedded: 1 \}/);
});

test("INT-19 route returns per-file results and no longer uses Promise.all move fan-out", () => {
  const route = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/api/document/index.js"), "utf8"
  );
  const start = route.indexOf('"/v1/document/move-files"');
  const end = route.indexOf('"/v1/document/generated-files/:filename"', start);
  assert.ok(start >= 0 && end > start);
  const block = route.slice(start, end);
  assert.match(block, /results\.push/);
  assert.match(block, /status: "moved"/);
  assert.match(block, /status: "failed"/);
  assert.match(block, /status: "embedded"/);
  assert.doesNotMatch(block, /Promise\.all\(movePromises\)/);
  assert.match(block, /moveFileNoReplace/);
});

test("ALLM-12 env-dump middleware remains in both endpoint files", () => {
  const apiSystem = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/api/system/index.js"), "utf8"
  );
  const system = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/system.js"), "utf8"
  );
  assert.match(apiSystem, /app\.get\("\/v1\/system\/env-dump", \[validApiKey\]/);
  assert.match(system, /app\.get\("\/env-dump", \[validApiKey\]/);
});

test("PUR-02 returns 404 for missing folder", async (t) => {
  const root = tempRoot(t);
  const purge = loadPurgeFolderFunction(root, { cache: [], documents: [] });
  await assert.rejects(() => purge("missing"), { statusCode: 404, code: "FOLDER_NOT_FOUND" });
});

test("PUR-02 refuses a symlink used as the target folder", async (t) => {
  const root = tempRoot(t);
  const outside = path.join(os.tmpdir(), `allm-purge-target-${process.pid}`);
  fs.mkdirSync(outside, { recursive: true });
  put(path.join(outside, "keep.txt"), "keep");
  t.after(() => fs.rmSync(outside, { recursive: true, force: true }));
  fs.symlinkSync(outside, path.join(root, "linked"));
  const purge = loadPurgeFolderFunction(root, { cache: [], documents: [] });
  await assert.rejects(() => purge("linked"), { statusCode: 400, code: "INVALID_FOLDER_TYPE" });
  assert.equal(fs.readFileSync(path.join(outside, "keep.txt"), "utf8"), "keep");
});

test("PUR-02 route adapters preserve structured status codes", () => {
  const api = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/api/document/index.js"), "utf8"
  );
  const system = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/system.js"), "utf8"
  );
  assert.match(api, /response\.status\(e\.statusCode \|\| 500\)\.json/);
  assert.match(system, /response\.status\(e\.statusCode \|\| 500\)\.json/);
});

function loadMoveFilesRoute(root, embeddedDocpaths = []) {
  const source = fs.readFileSync(
    path.join(__dirname, "../server/endpoints/api/document/index.js"), "utf8"
  );
  const routes = new Map();
  const embedded = new Set(embeddedDocpaths);
  const stubs = {
    "../../../models/telemetry": { Telemetry: {} },
    "../../../utils/middleware/validApiKey": { validApiKey() {} },
    "../../../utils/files/multer": { handleAPIFileUpload() {} },
    "../../../utils/files": {
      findDocumentInDocuments() {}, getDocumentsByFolder() {}, normalizePath() {},
      isWithin() {}, moveProcessedDocsToFolder() {}, viewLocalFiles() {},
    },
    "../../../utils/http": {
      reqBody: (request) => request.body,
      safeJsonParse: (value) => value,
      queryParams: () => ({}),
    },
    "../../../models/eventLogs": { EventLogs: {} },
    "../../../utils/collectorApi": { CollectorApi: {} },
    "../../../models/documents": {
      Document: { where: async () => [...embedded].map((docpath) => ({ docpath })) },
    },
    "../../../utils/files/purgeDocument": { purgeFolder: async () => ({ success: true }) },
    "../../../utils/agents/aibitat/plugins/create-files/lib": {},
    "../../../utils/files/safeMove": safeMove,
  };
  const module = { exports: {} };
  const sandbox = {
    require(name) {
      if (name === "fs") return fs;
      if (name === "path") return path;
      if (Object.prototype.hasOwnProperty.call(stubs, name)) return stubs[name];
      throw new Error(`Unexpected require in route test: ${name}`);
    },
    module,
    exports: module.exports,
    __dirname: path.join(root, "server", "endpoints", "api", "document"),
    process: { env: { NODE_ENV: "production", STORAGE_DIR: root } },
    console,
    Buffer,
  };
  vm.runInNewContext(source, sandbox, { filename: "api-document-index.js" });
  const app = {
    post(route, ...handlers) { routes.set(route, handlers[handlers.length - 1]); },
    get(route, ...handlers) { routes.set(route, handlers[handlers.length - 1]); },
    delete(route, ...handlers) { routes.set(route, handlers[handlers.length - 1]); },
  };
  module.exports.apiDocumentEndpoints(app);
  const handler = routes.get("/v1/document/move-files");
  assert.equal(typeof handler, "function", "INT-19 route registered");
  return handler;
}

test("INT-19 route performs real helper moves and reports mixed per-file outcomes", async (t) => {
  const root = tempRoot(t);
  const documents = path.join(root, "documents");
  put(path.join(documents, "source", "ok.txt"), "move-me");
  put(path.join(documents, "source", "embedded.txt"), "embedded-content");
  put(path.join(documents, "source", "blocked.txt"), "keep-source");
  put(path.join(documents, "target", "exists.txt"), "keep-destination");
  const handler = loadMoveFilesRoute(root, ["source/embedded.txt"]);
  const request = { body: { files: [
    { from: "source/ok.txt", to: "target/ok.txt" },
    { from: "source/embedded.txt", to: "target/embedded.txt" },
    { from: "source/blocked.txt", to: "target/exists.txt" },
  ] } };
  const response = {
    statusCode: 200,
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; },
  };
  await handler(request, response);
  assert.equal(response.statusCode, 200);
  assert.equal(response.body.success, false);
  assert.deepEqual(JSON.parse(JSON.stringify(response.body.summary)), { requested: 3, moved: 1, failed: 1, embedded: 1 });
  assert.deepEqual(Array.from(response.body.results, (item) => item.status), ["moved", "embedded", "failed"]);
  assert.equal(fs.readFileSync(path.join(documents, "target", "ok.txt"), "utf8"), "move-me");
  assert.equal(fs.existsSync(path.join(documents, "source", "ok.txt")), false);
  assert.equal(fs.readFileSync(path.join(documents, "source", "embedded.txt"), "utf8"), "embedded-content");
  assert.equal(fs.readFileSync(path.join(documents, "source", "blocked.txt"), "utf8"), "keep-source");
  assert.equal(fs.readFileSync(path.join(documents, "target", "exists.txt"), "utf8"), "keep-destination");
});
