# AnythingLLM — candidat de consolidation INT-18 / INT-19 / PUR-02

**Statut : candidat d’audit uniquement. Non déployé.**

Ce dossier contient des versions candidates de fichiers et un banc de tests Node.js. Il ne doit pas être copié en production sans revue et autorisation explicite.

## Sources de référence
Archive analysée : `CONSOLIDATION-SOURCES-20261028-210233.tar.gz`
SHA-256 de l’archive : `22f05ceb342ef6a7e881089f8f7c0230ef2fb0b96326cb4d2b5183b2db7fa4e9`

## Changements proposés
- **INT-18** : validation stricte des chemins, rejet des symlinks et des collisions, déplacement sans remplacement de destination, prévalidation du lot et tentative de retour arrière en cas d’échec.
- **INT-19** : traitement séquentiel par fichier, protection contre l’écrasement de destination, résultat individuel (`moved`, `failed`, `embedded`) et résumé de lot.
- **PUR-02** : purge récursive, refus des liens symboliques et du dossier protégé, nettoyage séquentiel des caches/associations, codes d’erreur structurés.
- **ALLM-12** : `endpoints/api/system/index.js` est conservé à l’identique de la production archivée. Pour `endpoints/system.js`, le correctif PUR-02 du laboratoire a été appliqué à la base de production archivée; le diff ne modifie que le gestionnaire de purge et conserve le middleware ALLM-12. Les tests vérifient les deux routes `env-dump`.

## Tests exécutés dans l’environnement de préparation
- `node --check` sur les fichiers JavaScript candidats et le test, sous Node.js v18.20.8.
- `node --test tests/safe-move.test.js` : **22 tests réussis, 0 échec** sous Node.js v18.20.8 dans un conteneur isolé construit depuis l’image de production. Les 22 tests passent également dans l’environnement de préparation Node.js v22.16.0.
- Le 22e test verrouille l’emplacement de la documentation Swagger INT-19 : les résultats par fichier sont documentés sur `POST /v1/document/move-files`, pas sur `POST /v1/document/create-folder`.
- Tests couvrant les déplacements, collisions, symlinks, traversal, retour arrière d’un lot, purge récursive, fichiers cachés, dossier protégé, erreurs de nettoyage, mapping de route et présence ALLM-12.

## Limites importantes
- Ces tests s’exécutent sur des fonctions extraites des fichiers candidats et des helpers réels; le banc simule les modèles `Document` et `Workspace`.
- Le test INT-19 invoque le vrai gestionnaire de route enregistré avec un faux objet Express et un modèle Document simulé; il ne lance pas l’application Express complète.
- Aucun test d’intégration n’a été exécuté contre la base SQL, LanceDB ou le cache de vecteurs. Les tests de code ont tourné dans un conteneur temporaire, sans réseau et avec les sources candidates montées en lecture seule; le conteneur de production n’a pas été modifié.
- Les erreurs sur plusieurs systèmes de fichiers, les interruptions du processus et les courses entre validation et opération nécessitent encore une revue et des tests ciblés.
- Le déplacement par lien physique puis suppression de la source suppose que source et destination se trouvent sur le même système de fichiers, ce qui est attendu car les deux chemins sont sous `documentsPath`; cela doit être confirmé dans le déploiement.
- La purge n’est pas transactionnelle. Si un nettoyage de cache ou de base échoue après des opérations précédentes, le dossier est conservé, mais les opérations précédentes ne sont pas annulées.
- Les quatre diffs de modification et le diff d’ajout du helper `safeMove.js` ont passé `patch --dry-run` contre les fichiers de production exacts de l’archive; après application sur une copie temporaire, les cinq fichiers partagés correspondent octet pour octet aux candidats. Le diff API-system est vide car ce fichier est conservé à l’identique.
- Aucun changement de production, aucune requête HTTP de production et aucun déploiement n’ont été effectués.

## Fichiers
La documentation Swagger de INT-19 a été mise à jour pour montrer le résumé et les résultats par fichier. Les fichiers sous `server/` sont des candidats complets pour les chemins correspondants. `PATCHES/` contient les diffs contre les sources de production archivées.
