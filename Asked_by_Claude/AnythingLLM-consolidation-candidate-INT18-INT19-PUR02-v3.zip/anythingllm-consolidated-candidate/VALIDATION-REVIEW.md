# Revue de consolidation — validation locale

Date de revue : 2026-10-29

## Résultats exécutés

- Image utilisée pour le test isolé : `sha256:ddf73304a4a96e2f90755d620dd3921de9afb4b8b8e914fa62d6ce7944ba95af` (`mintplexlabs/anythingllm:latest`), correspondant à l’image de production identifiée par l’utilisateur.
- Runtime du conteneur de test : Node.js v18.20.8.
- `node --check` : réussi pour les sept fichiers JavaScript candidats/testés.
- `node --test tests/safe-move.test.js` : 22 tests, 22 réussis, 0 échec sous Node.js v18.20.8; 22/22 également sous Node.js v22.16.0 dans l’environnement de préparation.
- Le conteneur de test a été lancé avec `--network none`, `--read-only` et les sources candidates montées en lecture seule. Aucun volume de production n’a été monté; aucune modification de production ni aucun déploiement n’ont eu lieu.
- Application des diffs : les diffs de code s’appliquent aux sources de production archivées. Après application dans une copie temporaire, les fichiers partagés correspondent aux candidats; le diff `api/system/index.js` est vide, car le fichier conserve la version production contenant ALLM-12.

## Couverture supplémentaire

- Test de déplacement sans remplacement, rejet des symlinks, traversée de chemin et rollback local / de lot.
- Tests PUR-02 sur purge récursive, fichiers cachés, dossier protégé, liens symboliques, erreurs de nettoyage et codes HTTP structurés.
- Test INT-19 qui invoque le gestionnaire de route enregistré avec un faux objet Express, le helper de déplacement réel et un modèle `Document` simulé; il vérifie un lot mêlant succès, document incorporé et collision.
- Test de régression documentaire : les exemples Swagger des résultats individuels sont associés à `POST /v1/document/move-files` et ne contaminent pas la documentation de `POST /v1/document/create-folder`.
- Test de présence du middleware ALLM-12 sur les deux routes `env-dump`.

## Limites qui restent ouvertes

- Il ne s’agit pas d’un test de l’application Express complète ni d’une intégration SQL / LanceDB / cache réel.
- `moveFileNoReplace` s’appuie sur `linkSync` puis `unlinkSync`; il suppose que source et destination sont sur le même système de fichiers. C’est attendu si les deux chemins sont sous `documentsPath`, mais doit être confirmé dans l’architecture réelle.
- Un échec de rollback est attaché à l’erreur sous `rollbackError` ou `rollbackFailures` et nécessite une intervention manuelle.
- La purge n’est pas transactionnelle vis-à-vis des caches et de la base : si une opération échoue, le dossier reste présent, mais les nettoyages antérieurs peuvent déjà avoir abouti.
- Les contrôles `lstat` atténuent les risques de liens symboliques, mais ne suppriment pas les courses entre validation et opération concurrente.

## Décision

Candidat d’audit uniquement. La compatibilité syntaxique et les tests unitaires Node.js 18 sont confirmés. Ne pas déployer avant les validations d’intégration restantes et l’autorisation explicite de l’utilisateur.
