const { Telemetry } = require("../../../models/telemetry");
const { validApiKey } = require("../../../utils/middleware/validApiKey");
const { handleAPIFileUpload } = require("../../../utils/files/multer");
const {
  findDocumentInDocuments,
  getDocumentsByFolder,
  normalizePath,
  isWithin,
  moveProcessedDocsToFolder,
  viewLocalFiles,
} = require("../../../utils/files");
const { reqBody, safeJsonParse, queryParams } = require("../../../utils/http");
const { EventLogs } = require("../../../models/eventLogs");
const { CollectorApi } = require("../../../utils/collectorApi");
const fs = require("fs");
const path = require("path");
const { moveFileNoReplace, resolveSafeRelative } = require("../../../utils/files/safeMove");
const { Document } = require("../../../models/documents");
const { purgeFolder } = require("../../../utils/files/purgeDocument");
const createFilesLib = require("../../../utils/agents/aibitat/plugins/create-files/lib");
const documentsPath =
  process.env.NODE_ENV === "development"
    ? path.resolve(__dirname, "../../../storage/documents")
    : path.resolve(process.env.STORAGE_DIR, `documents`);

/**
 * Runs a simple validation check on the addToWorkspaces query parameter to ensure it is a string of comma-separated workspace slugs.
 * @param {*} request
 * @param {*} response
 * @param {*} next
 * @returns
 */
function validateWorkspaceSlugQuery(request, response, next) {
  const { addToWorkspaces = "" } = reqBody(request);
  if (!addToWorkspaces) return next();
  if (typeof addToWorkspaces !== "string") {
    return response
      .status(422)
      .json({
        success: false,
        error: `addToWorkspaces must be a string of comma-separated workspace slugs. Got ${typeof addToWorkspaces}`,
      })
      .end();
  }
  next();
}

function apiDocumentEndpoints(app) {
  if (!app) return;

  app.post(
    "/v1/document/upload",
    [validApiKey, handleAPIFileUpload, validateWorkspaceSlugQuery],
    async (request, response) => {
      /*
    #swagger.tags = ['Documents']
    #swagger.description = 'Upload a new file to AnythingLLM to be parsed and prepared for embedding, with optional metadata.'
    #swagger.requestBody = {
      description: 'File to be uploaded.',
      required: true,
      content: {
        "multipart/form-data": {
          schema: {
            type: 'object',
            required: ['file'],
            properties: {
              file: {
                type: 'string',
                format: 'binary',
                description: 'The file to upload'
              },
              addToWorkspaces: {
                type: 'string',
                description: 'comma-separated text-string of workspace slugs to embed the document into post-upload. eg: workspace1,workspace2',
              },
              metadata: {
                type: 'object',
                description: 'Key:Value pairs of metadata to attach to the document in JSON Object format. Only specific keys are allowed - see example.',
                example: { 'title': 'Custom Title', 'docAuthor': 'Author Name', 'description': 'A brief description', 'docSource': 'Source of the document' }
              }
            },
            required: ['file']
          }
        }
      }
    }
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
              success: true,
              error: null,
              documents: [
                {
                  "location": "custom-documents/anythingllm.txt-6e8be64c-c162-4b43-9997-b068c0071e8b.json",
                  "name": "anythingllm.txt-6e8be64c-c162-4b43-9997-b068c0071e8b.json",
                  "url": "file:///Users/tim/Documents/anything-llm/collector/hotdir/anythingllm.txt",
                  "title": "anythingllm.txt",
                  "docAuthor": "Unknown",
                  "description": "Unknown",
                  "docSource": "a text file uploaded by the user.",
                  "chunkSource": "anythingllm.txt",
                  "published": "1/16/2024, 3:07:00 PM",
                  "wordCount": 93,
                  "token_count_estimate": 115,
                }
              ]
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
      try {
        const Collector = new CollectorApi();
        const { originalname } = request.file;
        const { addToWorkspaces = "", metadata: _metadata = {} } =
          reqBody(request);
        const metadata =
          typeof _metadata === "string"
            ? safeJsonParse(_metadata, {})
            : _metadata;
        const processingOnline = await Collector.online();

        if (!processingOnline) {
          response
            .status(500)
            .json({
              success: false,
              error: `Document processing API is not online. Document ${originalname} will not be processed automatically.`,
            })
            .end();
          return;
        }

        const { success, reason, documents } = await Collector.processDocument(
          originalname,
          metadata
        );

        if (!success) {
          return response
            .status(500)
            .json({ success: false, error: reason, documents })
            .end();
        }

        Collector.log(
          `Document ${originalname} uploaded processed and successfully. It is now available in documents.`
        );
        await Telemetry.sendTelemetry("document_uploaded");
        await EventLogs.logEvent("api_document_uploaded", {
          documentName: originalname,
        });

        if (!!addToWorkspaces) {
          const embedded = await Document.api.uploadToWorkspace(
            addToWorkspaces,
            documents.map((document) => document.location)
          );
          if (!embedded.success)
            return response
              .status(embedded.partial ? 200 : 500)
              .json({ success: false, error: embedded.error, documents });
        }
        response.status(200).json({ success: true, error: null, documents });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  app.post(
    "/v1/document/upload/:folderName",
    [validApiKey, handleAPIFileUpload, validateWorkspaceSlugQuery],
    async (request, response) => {
      /*
      #swagger.tags = ['Documents']
      #swagger.description = 'Upload a new file to a specific folder in AnythingLLM to be parsed and prepared for embedding. If the folder does not exist, it will be created.'
      #swagger.parameters['folderName'] = {
        in: 'path',
        description: 'Target folder path (defaults to \"custom-documents\" if not provided)',
        required: true,
        type: 'string',
        example: 'my-folder'
      }
      #swagger.requestBody = {
        description: 'File to be uploaded, with optional metadata.',
        required: true,
        content: {
          "multipart/form-data": {
            schema: {
              type: 'object',
              required: ['file'],
              properties: {
                file: {
                  type: 'string',
                  format: 'binary',
                  description: 'The file to upload'
                },
                addToWorkspaces: {
                  type: 'string',
                  description: 'comma-separated text-string of workspace slugs to embed the document into post-upload. eg: workspace1,workspace2',
                },
                metadata: {
                  type: 'object',
                  description: 'Key:Value pairs of metadata to attach to the document in JSON Object format. Only specific keys are allowed - see example.',
                  example: { 'title': 'Custom Title', 'docAuthor': 'Author Name', 'description': 'A brief description', 'docSource': 'Source of the document' }
                }
              }
            }
          }
        }
      }
      #swagger.responses[200] = {
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                success: true,
                error: null,
                documents: [{
                  "location": "custom-documents/anythingllm.txt-6e8be64c-c162-4b43-9997-b068c0071e8b.json",
                  "name": "anythingllm.txt-6e8be64c-c162-4b43-9997-b068c0071e8b.json",
                  "url": "file:///Users/tim/Documents/anything-llm/collector/hotdir/anythingllm.txt",
                  "title": "anythingllm.txt",
                  "docAuthor": "Unknown",
                  "description": "Unknown",
                  "docSource": "a text file uploaded by the user.",
                  "chunkSource": "anythingllm.txt",
                  "published": "1/16/2024, 3:07:00 PM",
                  "wordCount": 93,
                  "token_count_estimate": 115
                }]
              }
            }
          }
        }
      }
      #swagger.responses[403] = {
        schema: {
          "$ref": "#/definitions/InvalidAPIKey"
        }
      }
      #swagger.responses[500] = {
        description: "Internal Server Error",
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                success: false,
                error: "Document processing API is not online. Document will not be processed automatically."
              }
            }
          }
        }
      }
      */
      try {
        const { originalname } = request.file;
        const { addToWorkspaces = "", metadata: _metadata = {} } =
          reqBody(request);
        const metadata =
          typeof _metadata === "string"
            ? safeJsonParse(_metadata, {})
            : _metadata;

        const folderName = request.params?.folderName || "custom-documents";
        const Collector = new CollectorApi();
        const processingOnline = await Collector.online();
        if (!processingOnline) {
          return response
            .status(500)
            .json({
              success: false,
              error: `Document processing API is not online. Document ${originalname} will not be processed automatically.`,
            })
            .end();
        }

        // Process the uploaded document with metadata
        const { success, reason, documents } = await Collector.processDocument(
          originalname,
          metadata
        );
        if (!success) {
          return response
            .status(500)
            .json({ success: false, error: reason, documents })
            .end();
        }

        // For each processed document, check if it is already in the desired folder.
        // If not, move it using similar logic as in the move-files endpoint.
        const folder = moveProcessedDocsToFolder(documents, folderName);

        Collector.log(
          `Document ${originalname} uploaded, processed, and moved to folder ${folder} successfully.`
        );

        await Telemetry.sendTelemetry("document_uploaded");
        await EventLogs.logEvent("api_document_uploaded", {
          documentName: originalname,
          folder,
        });

        if (!!addToWorkspaces) {
          const embedded = await Document.api.uploadToWorkspace(
            addToWorkspaces,
            documents.map((document) => document.location)
          );
          if (!embedded.success)
            return response
              .status(embedded.partial ? 200 : 500)
              .json({ success: false, error: embedded.error, documents });
        }
        response.status(200).json({ success: true, error: null, documents });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  app.post(
    "/v1/document/upload-link",
    [validApiKey, validateWorkspaceSlugQuery],
    async (request, response) => {
      /*
    #swagger.tags = ['Documents']
    #swagger.description = 'Upload a valid URL for AnythingLLM to scrape and prepare for embedding. The link property can be a single URL string or an array of URL strings. Optionally, specify a comma-separated list of workspace slugs to embed the document into post-upload.'
    #swagger.requestBody = {
      description: 'Link of web address to be scraped and optionally a comma-separated list of workspace slugs to embed the document into post-upload, and optional metadata. The link property also accepts an array of links to process in a single request.',
      required: true,
      content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                "link": "https://anythingllm.com",
                "addToWorkspaces": "workspace1,workspace2",
                "scraperHeaders": {
                  "Authorization": "Bearer token123",
                  "My-Custom-Header": "value"
                },
                "metadata": {
                  "title": "Custom Title",
                  "docAuthor": "Author Name",
                  "description": "A brief description",
                  "docSource": "Source of the document"
                }
              }
            }
          }
        }
    }
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
              success: true,
              error: null,
              documents: [
                {
                  "id": "c530dbe6-bff1-4b9e-b87f-710d539d20bc",
                  "url": "file://useanything_com.html",
                  "title": "useanything_com.html",
                  "docAuthor": "no author found",
                  "description": "No description found.",
                  "docSource": "URL link uploaded by the user.",
                  "chunkSource": "https:anythingllm.com.html",
                  "published": "1/16/2024, 3:46:33 PM",
                  "wordCount": 252,
                  "pageContent": "AnythingLLM is the best....",
                  "token_count_estimate": 447,
                  "location": "custom-documents/url-useanything_com-c530dbe6-bff1-4b9e-b87f-710d539d20bc.json"
                }
              ]
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
      try {
        const Collector = new CollectorApi();
        const {
          link = "",
          addToWorkspaces = "",
          scraperHeaders = {},
          metadata: _metadata = {},
        } = reqBody(request);

        // `link` can be a single URL string or an array of URL strings.
        // Drop any non-string or empty entries - URL validation itself is
        // handled by the collector when each link is processed.
        const links = (Array.isArray(link) ? link : [link])
          .filter((url) => typeof url === "string" && url.trim().length > 0)
          .map((url) => url.trim());

        if (links.length === 0) {
          return response
            .status(422)
            .json({
              success: false,
              error:
                "link must be a non-empty string or an array of non-empty strings.",
              documents: [],
            })
            .end();
        }

        const metadata =
          typeof _metadata === "string"
            ? safeJsonParse(_metadata, {})
            : _metadata;
        const processingOnline = await Collector.online();

        if (!processingOnline) {
          return response
            .status(500)
            .json({
              success: false,
              error: `Document processing API is not online. Link(s) ${links.join(", ")} will not be processed automatically.`,
              documents: [],
            })
            .end();
        }

        const results = await Promise.all(
          links.map(async (url) => ({
            url,
            ...(await Collector.processLink(url, scraperHeaders, metadata)),
          }))
        );

        const documents = [];
        const failures = [];
        for (const result of results) {
          const {
            url,
            success,
            reason,
            documents: linkDocuments = [],
          } = result;
          if (!success) {
            failures.push({ url, reason: reason || "Failed to process link." });
            continue;
          }

          Collector.log(
            `Link ${url} uploaded processed and successfully. It is now available in documents.`
          );
          await Telemetry.sendTelemetry("link_uploaded");
          await EventLogs.logEvent("api_link_uploaded", { link: url });
          documents.push(...linkDocuments);
        }

        let embedded = { success: true, partial: false, error: null };
        if (!!addToWorkspaces && documents.length > 0)
          embedded = await Document.api.uploadToWorkspace(
            addToWorkspaces,
            documents.map((document) => document.location)
          );

        const linkError =
          failures.length === 0
            ? null
            : links.length === 1
              ? failures[0].reason
              : failures
                  .map(({ url, reason }) => `${url}: ${reason}`)
                  .join("; ");
        const error =
          [linkError, embedded.error].filter(Boolean).join("; ") || null;

        // Nothing reached the documents folder, or nothing reached the workspace.
        if (
          (documents.length === 0 && failures.length > 0) ||
          (!embedded.success && !embedded.partial)
        ) {
          return response
            .status(500)
            .json({ success: false, error, documents })
            .end();
        }

        response.status(200).json({
          success: failures.length === 0 && embedded.success,
          error,
          documents,
        });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  app.post(
    "/v1/document/raw-text",
    [validApiKey, validateWorkspaceSlugQuery],
    async (request, response) => {
      /*
     #swagger.tags = ['Documents']
     #swagger.description = 'Upload a file by specifying its raw text content and metadata values without having to upload a file.'
     #swagger.requestBody = {
      description: 'Text content and metadata of the file to be saved to the system. Use metadata-schema endpoint to get the possible metadata keys',
      required: true,
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
              "textContent": "This is the raw text that will be saved as a document in AnythingLLM.",
              "addToWorkspaces": "workspace1,workspace2",
              "metadata": {
                "title": "This key is required. See in /server/endpoints/api/document/index.js:287",
                "keyOne": "valueOne",
                "keyTwo": "valueTwo",
                "etc": "etc"
              }
            }
          }
        }
      }
     }
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
              success: true,
              error: null,
              documents: [
                {
                  "id": "c530dbe6-bff1-4b9e-b87f-710d539d20bc",
                  "url": "file://my-document.txt",
                  "title": "hello-world.txt",
                  "docAuthor": "no author found",
                  "description": "No description found.",
                  "docSource": "My custom description set during upload",
                  "chunkSource": "no chunk source specified",
                  "published": "1/16/2024, 3:46:33 PM",
                  "wordCount": 252,
                  "pageContent": "AnythingLLM is the best....",
                  "token_count_estimate": 447,
                  "location": "custom-documents/raw-my-doc-text-c530dbe6-bff1-4b9e-b87f-710d539d20bc.json"
                }
              ]
            }
          }
        }
      }
     }
     #swagger.responses[403] = {
       schema: {
         "$ref": "#/definitions/InvalidAPIKey"
       }
     }
     */
      try {
        const Collector = new CollectorApi();
        const requiredMetadata = ["title"];
        const {
          textContent,
          metadata: _metadata = {},
          addToWorkspaces = "",
        } = reqBody(request);
        const metadata =
          typeof _metadata === "string"
            ? safeJsonParse(_metadata, {})
            : _metadata;
        const processingOnline = await Collector.online();

        if (!processingOnline) {
          return response
            .status(500)
            .json({
              success: false,
              error: `Document processing API is not online. Request will not be processed.`,
            })
            .end();
        }

        if (
          !requiredMetadata.every(
            (reqKey) =>
              Object.keys(metadata).includes(reqKey) && !!metadata[reqKey]
          )
        ) {
          return response
            .status(422)
            .json({
              success: false,
              error: `You are missing required metadata key:value pairs in your request. Required metadata key:values are ${requiredMetadata
                .map((v) => `'${v}'`)
                .join(", ")}`,
            })
            .end();
        }

        if (!textContent || textContent?.length === 0) {
          return response
            .status(422)
            .json({
              success: false,
              error: `The 'textContent' key cannot have an empty value.`,
            })
            .end();
        }

        const { success, reason, documents } = await Collector.processRawText(
          textContent,
          metadata
        );
        if (!success) {
          return response
            .status(500)
            .json({ success: false, error: reason, documents })
            .end();
        }

        Collector.log(
          `Document created successfully. It is now available in documents.`
        );
        await Telemetry.sendTelemetry("raw_document_uploaded");
        await EventLogs.logEvent("api_raw_document_uploaded");

        if (!!addToWorkspaces) {
          const embedded = await Document.api.uploadToWorkspace(
            addToWorkspaces,
            documents.map((document) => document.location)
          );
          if (!embedded.success)
            return response
              .status(embedded.partial ? 200 : 500)
              .json({ success: false, error: embedded.error, documents });
        }
        response.status(200).json({ success: true, error: null, documents });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  app.get("/v1/documents", [validApiKey], async (request, response) => {
    /*
    #swagger.tags = ['Documents']
    #swagger.description = 'List of all locally-stored documents in instance. Optionally, pass ?folder=name to fetch the contents of a single folder, paginated with offset and limit (limit=all returns every document in that folder).'
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
             "localFiles": {
              "name": "documents",
              "type": "folder",
              items: [
                {
                  "name": "my-stored-document.json",
                  "type": "file",
                  "id": "bb07c334-4dab-4419-9462-9d00065a49a1",
                  "url": "file://my-stored-document.txt",
                  "title": "my-stored-document.txt",
                  "cached": false
                },
              ]
             }
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
    try {
      const { folder, offset, limit } = queryParams(request);
      if (folder) {
        // Additive opt-in. Pagination is passed through as-is:
        // getDocumentsByFolder clamps the window and understands `limit=all`.
        const result = await getDocumentsByFolder(folder, { offset, limit });
        response.status(result.code).json(result);
      } else {
        // Deliberately the full tree, unchanged from before folder support
        // existed. This parses every document on disk and is slow on large
        // instances, but silently returning empty `items` arrays to existing
        // integrations would be worse. New callers should use ?folder=.
        const localFiles = await viewLocalFiles();
        response.status(200).json({ localFiles });
      }
    } catch (e) {
      console.error(e.message, e);
      response.sendStatus(500).end();
    }
  });

  app.get(
    "/v1/documents/folder/:folderName",
    [validApiKey],
    async (request, response) => {
      /*
    #swagger.tags = ['Documents']
    #swagger.description = 'Get all documents stored in a specific folder. Returns every document by default; pass offset and limit to paginate.'
    #swagger.parameters['folderName'] = {
      in: 'path',
      description: 'Name of the folder to retrieve documents from',
      required: true,
      type: 'string'
    }
    #swagger.parameters['offset'] = {
      in: 'query',
      description: 'Number of documents to skip. Defaults to 0.',
      required: false,
      type: 'integer'
    }
    #swagger.parameters['limit'] = {
      in: 'query',
      description: "Max documents to return, capped at 1000. Defaults to all, which returns every document in the folder.",
      required: false,
      type: 'string'
    }
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
              folder: "custom-documents",
              documents: [
                {
                  name: "document1.json",
                  type: "file",
                  cached: false,
                  pinnedWorkspaces: [],
                  watched: false,
                  more: "data",
                },
                {
                  name: "document2.json",
                  type: "file",
                  cached: false,
                  pinnedWorkspaces: [],
                  watched: false,
                  more: "data",
                },
              ]
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
      try {
        const { folderName } = request.params;
        const { offset, limit = "all" } = queryParams(request);
        // Defaults to every document: this endpoint has never paginated and
        // silently truncating to a page would break existing consumers.
        // offset/limit are opt-in for callers that do want to page.
        const result = await getDocumentsByFolder(folderName, {
          offset,
          limit,
        });
        response.status(result.code).json({
          folder: result.folder,
          documents: result.documents,
          totalCount: result.totalCount,
          hasMore: result.hasMore,
          error: result.error,
        });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  app.get(
    "/v1/document/accepted-file-types",
    [validApiKey],
    async (_, response) => {
      /*
    #swagger.tags = ['Documents']
    #swagger.description = 'Check available filetypes and MIMEs that can be uploaded.'
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
              "types": {
                "application/mbox": [
                  ".mbox"
                ],
                "application/pdf": [
                  ".pdf"
                ],
                "application/vnd.oasis.opendocument.text": [
                  ".odt"
                ],
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
                  ".docx"
                ],
                "text/plain": [
                  ".txt",
                  ".md"
                ]
              }
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
      try {
        const types = await new CollectorApi().acceptedFileTypes();
        if (!types) {
          response.sendStatus(404).end();
          return;
        }

        response.status(200).json({ types });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  app.get(
    "/v1/document/metadata-schema",
    [validApiKey],
    async (_, response) => {
      /*
    #swagger.tags = ['Documents']
    #swagger.description = 'Get the known available metadata schema for when doing a raw-text upload and the acceptable type of value for each key.'
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
             "schema": {
                "keyOne": "string | number | nullable",
                "keyTwo": "string | number | nullable",
                "specialKey": "number",
                "title": "string",
              }
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
      try {
        response.status(200).json({
          schema: {
            // If you are updating this be sure to update the collector METADATA_KEYS constant in /processRawText.
            url: "string | nullable",
            title: "string",
            docAuthor: "string | nullable",
            description: "string | nullable",
            docSource: "string | nullable",
            chunkSource: "string | nullable",
            published: "epoch timestamp in ms | nullable",
          },
        });
      } catch (e) {
        console.error(e.message, e);
        response.sendStatus(500).end();
      }
    }
  );

  // Be careful and place as last route to prevent override of the other /document/ GET
  // endpoints!
  app.get("/v1/document/:docName", [validApiKey], async (request, response) => {
    /*
    #swagger.tags = ['Documents']
    #swagger.description = 'Get a single document by its unique AnythingLLM document name'
    #swagger.parameters['docName'] = {
        in: 'path',
        description: 'Unique document name to find (name in /documents)',
        required: true,
        type: 'string'
    }
    #swagger.responses[200] = {
      content: {
        "application/json": {
          schema: {
            type: 'object',
            example: {
             "localFiles": {
              "name": "documents",
              "type": "folder",
              items: [
                {
                  "name": "my-stored-document.txt-uuid1234.json",
                  "type": "file",
                  "id": "bb07c334-4dab-4419-9462-9d00065a49a1",
                  "url": "file://my-stored-document.txt",
                  "title": "my-stored-document.txt",
                  "cached": false
                },
              ]
             }
            }
          }
        }
      }
    }
    #swagger.responses[403] = {
      schema: {
        "$ref": "#/definitions/InvalidAPIKey"
      }
    }
    */
    try {
      const { docName } = request.params;
      const document = await findDocumentInDocuments(docName);
      if (!document) {
        response.sendStatus(404).end();
        return;
      }
      response.status(200).json({ document });
    } catch (e) {
      console.error(e.message, e);
      response.sendStatus(500).end();
    }
  });

  app.post(
    "/v1/document/create-folder",
    [validApiKey],
    async (request, response) => {
      /*
      #swagger.tags = ['Documents']
      #swagger.description = 'Create a new folder inside the documents storage directory.'
      #swagger.requestBody = {
        description: 'Name of the folder to create.',
        required: true,
        content: {
          "application/json": {
            schema: {
              type: 'string',
              example: {
                "name": "new-folder"
              }
            }
          }
        }
      }
      #swagger.responses[200] = {
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                success: true,
                message: null
              }
            }
          }
        }
      }
      #swagger.responses[403] = {
        schema: {
          "$ref": "#/definitions/InvalidAPIKey"
        }
      }
      */
      try {
        const { name } = reqBody(request);
        const storagePath = path.join(documentsPath, normalizePath(name));
        if (!isWithin(path.resolve(documentsPath), path.resolve(storagePath)))
          throw new Error("Invalid path name");

        if (fs.existsSync(storagePath)) {
          response.status(500).json({
            success: false,
            message: "Folder by that name already exists",
          });
          return;
        }

        fs.mkdirSync(storagePath, { recursive: true });
        response.status(200).json({ success: true, message: null });
      } catch (e) {
        console.error(e);
        response.status(500).json({
          success: false,
          message: `Failed to create folder: ${e.message}`,
        });
      }
    }
  );

  app.delete(
    "/v1/document/remove-folder",
    [validApiKey],
    async (request, response) => {
      /*
      #swagger.tags = ['Documents']
      #swagger.description = 'Remove a folder and all its contents from the documents storage directory.'
      #swagger.requestBody = {
        description: 'Name of the folder to remove.',
        required: true,
        content: {
          "application/json": {
            schema: {
              type: 'object',
              properties: {
                name: {
                  type: 'string',
                  example: "my-folder"
                }
              }
            }
          }
        }
      }
      #swagger.responses[200] = {
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                success: true,
                message: "Folder removed successfully"
              }
            }
          }
        }
      }
      #swagger.responses[403] = {
        schema: {
          "$ref": "#/definitions/InvalidAPIKey"
        }
      }
      */
      try {
        const { name } = reqBody(request);
        const result = await purgeFolder(name);
        response.status(200).json(result);
      } catch (e) {
        console.error(e);
        response.status(e.statusCode || 500).json({
          success: false,
          code: e.code || "FOLDER_PURGE_FAILED",
          message: e.message ? `Failed to remove folder: ${e.message}` : "Failed to remove folder.",
        });
      }
    }
  );

  app.post(
    "/v1/document/move-files",
    [validApiKey],
    async (request, response) => {
      /*
      #swagger.tags = ['Documents']
      #swagger.description = 'Move files within the documents storage directory.'
      #swagger.requestBody = {
        description: 'Array of objects containing source and destination paths of files to move.',
        required: true,
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                "files": [
                  {
                    "from": "custom-documents/file.txt-fc4beeeb-e436-454d-8bb4-e5b8979cb48f.json",
                    "to": "folder/file.txt-fc4beeeb-e436-454d-8bb4-e5b8979cb48f.json"
                  }
                ]
              }
            }
          }
        }
      }
      #swagger.responses[200] = {
        description: 'The batch was processed. Inspect success and each result; individual files may fail while others move successfully.',
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                success: false,
                message: 'Some files were not moved; inspect results for each file.',
                summary: { requested: 3, moved: 1, failed: 1, embedded: 1 },
                results: [
                  { from: 'source/a.json', to: 'target/a.json', status: 'moved', success: true },
                  { from: 'source/b.json', to: 'target/b.json', status: 'embedded', success: false, error: 'Unembed this document from all workspaces before moving it.' },
                  { from: 'source/c.json', to: 'target/c.json', status: 'failed', success: false, error: 'Destination already exists.', code: 'EEXIST' }
                ]
              }
            }
          }
        }
      }
      #swagger.responses[400] = {
        description: 'The request body is invalid.',
        content: { "application/json": { schema: { type: 'object', example: { success: false, message: '"files" must be an array.', results: [] } } }
      }
      #swagger.responses[403] = {
        schema: {
          "$ref": "#/definitions/InvalidAPIKey"
        }
      }
      */
      try {
        const { files } = reqBody(request);
        if (!Array.isArray(files)) {
          return response.status(400).json({
            success: false,
            message: '"files" must be an array.',
            results: [],
          });
        }

        const docpaths = files
          .filter((item) => item && typeof item.from === "string")
          .map(({ from }) => from);
        const documents = docpaths.length
          ? await Document.where({ docpath: { in: docpaths } })
          : [];
        const embeddedFiles = new Set(documents.map((doc) => doc.docpath));
        const results = [];

        for (const item of files) {
          const from = item && item.from;
          const to = item && item.to;
          if (typeof from !== "string" || typeof to !== "string") {
            results.push({
              from: from ?? null,
              to: to ?? null,
              status: "failed",
              success: false,
              error: 'Each item must contain string "from" and "to" paths.',
            });
            continue;
          }

          if (embeddedFiles.has(from)) {
            results.push({
              from,
              to,
              status: "embedded",
              success: false,
              error: "Unembed this document from all workspaces before moving it.",
            });
            continue;
          }

          try {
            const sourcePath = resolveSafeRelative(documentsPath, from);
            const destinationPath = resolveSafeRelative(documentsPath, to);
            moveFileNoReplace(documentsPath, sourcePath, destinationPath);
            results.push({ from, to, status: "moved", success: true });
          } catch (error) {
            results.push({
              from,
              to,
              status: "failed",
              success: false,
              error: error.message || "Move failed.",
              code: error.code || "MOVE_FAILED",
            });
          }
        }

        const success = results.every((result) => result.success);
        const movedCount = results.filter((result) => result.status === "moved").length;
        const failedCount = results.filter((result) => result.status === "failed").length;
        const embeddedCount = results.filter((result) => result.status === "embedded").length;
        response.status(200).json({
          success,
          message: success ? null : "Some files were not moved; inspect results for each file.",
          summary: {
            requested: files.length,
            moved: movedCount,
            failed: failedCount,
            embedded: embeddedCount,
          },
          results,
        });
      } catch (e) {
        console.error(e);
        response
          .status(500)
          .json({ success: false, message: "Failed to move files." });
      }
    }
  );

  app.get(
    "/v1/document/generated-files/:filename",
    [validApiKey],
    async (request, response) => {
      /*
      #swagger.tags = ['Documents']
      #swagger.description = 'Download a file generated by an agent skill (e.g., PDF, DOCX, XLSX, PPTX) or a generated image (img-*.png). The filename is returned in the `outputs` array of a chat response when an agent generates a file or image. Use the `storageFilename` value from that response to download the file.'
      #swagger.parameters['filename'] = {
        in: 'path',
        description: 'The storage filename returned in the chat response outputs array (e.g., pdf-e9e14f28-d6b6-4f49-91a0-dd331517f567.pdf)',
        required: true,
        type: 'string'
      }
      #swagger.responses[200] = {
        description: 'File downloaded successfully',
        content: {
          "application/octet-stream": {
            schema: {
              type: 'string',
              format: 'binary'
            }
          }
        }
      }
      #swagger.responses[400] = {
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                error: "Invalid filename format"
              }
            }
          }
        }
      }
      #swagger.responses[403] = {
        schema: {
          "$ref": "#/definitions/InvalidAPIKey"
        }
      }
      #swagger.responses[404] = {
        content: {
          "application/json": {
            schema: {
              type: 'object',
              example: {
                error: "File not found"
              }
            }
          }
        }
      }
      */
      try {
        const { filename } = request.params;
        if (!filename)
          return response.status(400).json({ error: "Filename is required" });

        // Generated images live in their own storage directory, separate from
        // the create-files output directory the block below reads from.
        const {
          generatedImagesPath,
          GENERATED_IMAGE_FILENAME_PATTERN,
        } = require("../../../utils/files");
        if (GENERATED_IMAGE_FILENAME_PATTERN.test(filename)) {
          const imagePath = path.resolve(generatedImagesPath, filename);
          if (
            !isWithin(generatedImagesPath, imagePath) ||
            !fs.existsSync(imagePath)
          )
            return response.status(404).json({ error: "File not found" });

          const imageBuffer = await fs.promises.readFile(imagePath);
          response.setHeader("Content-Type", "image/png");
          response.setHeader(
            "Content-Disposition",
            `attachment; filename="${createFilesLib.sanitizeFilenameForHeader(filename)}"`
          );
          response.setHeader("Content-Length", imageBuffer.length);
          response.send(imageBuffer);
          Telemetry.sendTelemetry("agent_generated_file_downloaded", {
            type: "image/png",
          }).catch(() => {});
          return;
        }

        const parsed = createFilesLib.parseFilename(filename);
        if (!parsed) {
          return response
            .status(400)
            .json({ error: "Invalid filename format" });
        }

        const fileData = await createFilesLib.getGeneratedFile(filename);
        if (!fileData) {
          return response.status(404).json({ error: "File not found" });
        }

        const mimeType = createFilesLib.getMimeType(`.${parsed.extension}`);
        const safeFilename = createFilesLib.sanitizeFilenameForHeader(filename);
        response.setHeader("Content-Type", mimeType);
        response.setHeader(
          "Content-Disposition",
          `attachment; filename="${safeFilename}"`
        );
        response.setHeader("Content-Length", fileData.buffer.length);
        response.send(fileData.buffer);

        Telemetry.sendTelemetry("agent_generated_file_downloaded", {
          type: mimeType,
        }).catch(() => {});
      } catch (error) {
        console.error(
          "[document/generated-files] Download error:",
          error.message
        );
        return response.status(500).json({ error: "Failed to download file" });
      }
    }
  );
}

module.exports = { apiDocumentEndpoints };
