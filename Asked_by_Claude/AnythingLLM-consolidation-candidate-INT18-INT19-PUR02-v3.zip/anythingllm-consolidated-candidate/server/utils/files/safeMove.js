const fs = require("fs");
const path = require("path");

function isWithinRoot(rootPath, candidatePath) {
  const root = path.resolve(rootPath);
  const candidate = path.resolve(candidatePath);
  const relative = path.relative(root, candidate);
  return relative !== "" && relative !== ".." &&
    !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative);
}
function fail(message, code = "INVALID_PATH") {
  const error = new Error(message);
  error.code = code;
  return error;
}
function assertRoot(rootPath) {
  const root = path.resolve(rootPath);
  const stat = fs.lstatSync(root);
  if (stat.isSymbolicLink() || !stat.isDirectory())
    throw fail("Storage root must be a real directory.", "INVALID_ROOT");
  return root;
}
function assertSafeDirectory(rootPath, directoryPath) {
  const root = assertRoot(rootPath);
  const target = path.resolve(directoryPath);
  if (target !== root && !isWithinRoot(root, target))
    throw fail("Directory is outside storage root.");
  const relative = path.relative(root, target);
  let current = root;
  if (!relative) return root;
  for (const segment of relative.split(path.sep)) {
    current = path.join(current, segment);
    const stat = fs.lstatSync(current);
    if (stat.isSymbolicLink() || !stat.isDirectory())
      throw fail("Path contains a symlink or non-directory component.", "UNSAFE_PATH");
  }
  return target;
}
function assertSafeRegularFile(rootPath, filePath) {
  const root = assertRoot(rootPath);
  const target = path.resolve(filePath);
  if (!isWithinRoot(root, target)) throw fail("File is outside storage root.");
  assertSafeDirectory(root, path.dirname(target));
  const stat = fs.lstatSync(target);
  if (stat.isSymbolicLink() || !stat.isFile())
    throw fail("Source must be a regular non-symlink file.", "UNSAFE_SOURCE");
  return target;
}
function assertSafeDestination(rootPath, destinationPath) {
  const root = assertRoot(rootPath);
  const target = path.resolve(destinationPath);
  if (!isWithinRoot(root, target)) throw fail("Destination is outside storage root.");
  assertSafeDirectory(root, path.dirname(target));
  try {
    fs.lstatSync(target);
    throw fail("Destination already exists.", "EEXIST");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  return target;
}
function validateMove(rootPath, sourcePath, destinationPath) {
  const source = assertSafeRegularFile(rootPath, sourcePath);
  const destination = assertSafeDestination(rootPath, destinationPath);
  if (source === destination) throw fail("Source and destination are identical.");
  return { source, destination };
}
/**
 * Move a regular file without overwriting an existing destination.
 * Both paths must live under the same storage root/filesystem.
 */
function moveFileNoReplace(rootPath, sourcePath, destinationPath) {
  const { source, destination } = validateMove(rootPath, sourcePath, destinationPath);
  fs.linkSync(source, destination);
  try {
    fs.unlinkSync(source);
  } catch (error) {
    try { fs.unlinkSync(destination); }
    catch (rollbackError) { error.rollbackError = rollbackError; }
    throw error;
  }
  return { source, destination };
}
function resolveSafeRelative(rootPath, relativePath) {
  if (typeof relativePath !== "string" || !relativePath.trim())
    throw fail("A relative file path is required.");
  const raw = relativePath.trim();
  if (path.isAbsolute(raw) || raw.includes("\\") ||
      raw.split("/").some((part) => part === "." || part === ".." || part === "")) {
    throw fail("Only normalized relative paths are allowed.");
  }
  const resolved = path.resolve(rootPath, raw);
  if (!isWithinRoot(rootPath, resolved)) throw fail("Path is outside storage root.");
  return resolved;
}
module.exports = {
  isWithinRoot, assertSafeDirectory, assertSafeRegularFile,
  assertSafeDestination, validateMove, moveFileNoReplace, resolveSafeRelative,
};
